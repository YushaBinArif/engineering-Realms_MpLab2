package com.example.saminaarif.copycutpasteapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.zip.Inflater;

public class MainActivity extends AppCompatActivity {
    String buffer;
    EditText editText ;
    TextView textView ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = (EditText) findViewById(R.id.editText);
        textView = (TextView) findViewById(R.id.textView);
        registerForContextMenu(textView);
    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return  true ;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.context_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getTitle().toString().toLowerCase())
        {
            case "paste" :
                textView.setText(buffer);
                break;
            case "clear":
                textView.setText(" ");
                break;
        }
        return super.onContextItemSelected(item);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getTitle().toString().toLowerCase())
        {
            case "copy":
                buffer = editText.getText().toString();
                Toast.makeText(this, "Text Copied", Toast.LENGTH_SHORT).show();
                break;
            case "cut":
                buffer = editText.getText().toString();
                editText.setText("");
                Toast.makeText(this, "Text Copied", Toast.LENGTH_SHORT).show();
                break;
            case "paste":
                try
                {
                    if(!buffer.isEmpty())
                    {
                        textView.setText(buffer);
                    }
                    else
                    {
                        Toast.makeText(this, "Nothing to paste", Toast.LENGTH_SHORT).show();
                    }
                }
                catch (Exception e)
                {}



                break;
        }
        return true;
    }

}
